/**
 * Created by lindsaychen on 2017-05-30.
 */
public class q5Euler {
    public static void main(String[] args) {
        double y =1;
        double h=0.25;

        for (double x=0.0; x<=1.0;x=x+h) {
            System.out.println(x +"    "+ y);
            y= y+h*(1+2*x)*Math.pow(y,0.5);
        }

    }
}




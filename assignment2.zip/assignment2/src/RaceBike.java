/**
 * Created by lindsaychen on 2017-06-01.
 */
public class RaceBike extends Bike{
    public RaceBike(int wheels, double price, String size, int yearOfProduce, boolean wonBefore, String name) {
        super(wheels, price, size);
        this.yearOfProduce = yearOfProduce;
        this.wonBefore = wonBefore;
        this.name = name;
    }

    // 3 fields
    private int yearOfProduce;
    private boolean wonBefore;
    private String name;


    // 2 methods
    public void winning() {
        System.out.println("I am winning!");
    }

    public int getYearOfProduce() {
        return yearOfProduce;
    }

}

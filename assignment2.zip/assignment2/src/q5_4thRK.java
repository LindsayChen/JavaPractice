/**
 * Created by lindsaychen on 2017-05-31.
 */
public class q5_4thRK {
    public static void main(String[] args) {
        double y = 1;
        double h = 0.25;
        double k1;
        double k2;
        double k3;
        double k4;

        for (double x=0; x<=1;x=x+h) {
            System.out.println(x +"    "+ y);
            k1=(1+2*x)*Math.pow(y,0.5);
            k2=(1+2*(x+0.5*h))*Math.pow((y+0.5*k1*h),0.5);
            k3=(1+2*(x+0.5*h))*Math.pow((y+0.5*k2*h),0.5);
            k4=(1+2*(x+h))*Math.pow((y+k3*h),0.5);
            y= y+(k1+2*k2+2*k3+k4)*h/6.0;
        }

    }
}

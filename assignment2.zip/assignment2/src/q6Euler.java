/**
 * Created by lindsaychen on 2017-05-31.
 */
public class q6Euler {
    public static void main(String[] args) {
        double y =1;
        double h=0.1;

        for (double x=1; x<1.4;x=x+h) {
            System.out.println(x +"    "+ y);
            y= y+h*(x*y+5*Math.pow(x,2)*y);
        }

    }
}

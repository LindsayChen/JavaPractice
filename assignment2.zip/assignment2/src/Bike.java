/**
 * Created by lindsaychen on 2017-05-30.
 */
public class Bike {

    // the Bike class has 10 fields
    private int wheels;
    private double weight;
    private double length;
    private double height;
    private double price;
    private double speed;
    private String color;
    private String brand;
    private String condition;
    private String size;


    // the Bike class has 5 methods
    public static void main(String[] args) {
        // 3 instances of the Bike class
        Bike myFirstBike = new Bike(3,299.99,"Small");
        Bike mySecondBike = new Bike(2,5.2, 1.8,1.6,250.00,20,"black");
        Bike myThirdBike = new Bike("white", "Giant","new","Big");
    }

    public void slowDown(double decrement){
        speed -= decrement;
    }

    public void speedUp(double increment){
        speed += increment;
    }

    public void moving(double speed1) {
        System.out.println("I am moving at" + speed1 + "m/s");
    }

    public void stop(double speed0) {
        System.out.println("I stopped!");
    }

    // the Bike class has 3 overloading constructor
    public Bike(int wheels, double price, String size) {
        this.wheels = wheels;
        this.price = price;
        this.size = size;
    }

    public Bike(int wheels, double weight, double length, double height, double price, double speed, String color) {
        this.wheels = wheels;
        this.weight = weight;
        this.length = length;
        this.height = height;
        this.price = price;
        this.speed = speed;
        this.color = color;
    }

    public Bike(String color, String brand, String condition, String size) {
        this.color = color;
        this.brand = brand;
        this.condition = condition;
        this.size = size;
    }
}

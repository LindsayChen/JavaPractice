/**
 * Created by lindsaychen on 2017-06-01.
 */
import java.util.*;

public class BankAccount {
    private int accountNumber;
    private double balance;
    private String userName;

    // Constructor to initialized the account
    public BankAccount(int startAccountNumber, double startBalance, String startUserName) {
        accountNumber = startAccountNumber;
        balance = startBalance;
        userName = startUserName;
    }

    // Method to deposit
    public void depositing(double amount) {
        if (amount >= 10000) {
            System.out.println("Depositing more than $10,000 is not allowed!\n");
        }
        else {
            balance = balance + amount;
            System.out.println("You have deposited " + amount +".\n");
        }
    }

    // Method to withdraw
    public void withdrawing(double amount) {
        if (balance < amount) {
            System.out.println("You are not allowed to withdraw more than your balance!\n");
        }
        else {
            balance = balance - amount;
            System.out.println("You have withdrawn " + amount + ".\n");
        }
    }

    // Method to return current balance
    public double getBalance() {
        return balance;
    }

    // Method to return account number
    public int getAccountNumber() {
        return accountNumber;
    }


    // Main method to create an account object and perform methods on this object
    public static void main(String[] args) {
        String input;
        System.out.println("Please enter your user name:");
        String userName1 = new Scanner(System.in).next();
        int accountNumber1 = new Random().nextInt(999999999);
        System.out.println("Your account has been created.\n");

        // Create account 1
        BankAccount account1 = new BankAccount(accountNumber1, 0, userName1);

        do {
            System.out.println("Please enter your option by title or number:\n 1.Check account number\n 2.Change name\n 3.Check balance\n 4.Withdraw\n 5.Deposit\n 6.Quit");

            input = new Scanner(System.in).next();

            switch (input) {
                case "1":
                case "Check account number":
                    System.out.println("Your account number is " + account1.getAccountNumber() +"\n");
                    break;
                case "2":
                case"Change name":
                    System.out.println("Enter your new name:");
                    String Name = new Scanner(System.in).next();
                    if (Name.equals(userName1)) {
                        System.out.println("The new name you typed is same as the existing name for the account.\n");
                    } else {
                        System.out.println("You have changed your name to " + Name + ".\n");
                    }
                    break;
                case "3":
                case"Change balance":
                    System.out.println("Your account balance is " + account1.getBalance());
                    break;
                case "4":
                case "Withdraw":
                    System.out.println("Please enter the amount you want to withdraw:");
                    double amountW = new Scanner(System.in).nextDouble();
                    account1.withdrawing(amountW);
                    break;
                case "5":
                case"Deposit":
                    System.out.println("Please enter the amount you want to deposit:");
                    double amountD = new Scanner(System.in).nextDouble();
                    account1.depositing(amountD);
                    break;
                case "6":
                case "Quit":
                    System.out.println("You are leaving your account.");
                    break;
                default:
                    System.out.println("Please enter a valid input.\n");
                    break;
            }
        } while(!input.equals("6"));

    }
}

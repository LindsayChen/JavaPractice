/**
 * Created by lindsaychen on 2017-05-30.
 */
public class q5Analytical {
    public static void main(String[] args) {
        double y=1;
        double y1=1;
        double h=0.25;

        for (double x=0; x<=1;x=x+h) {
            y= 0.25*Math.pow((x*x+x-2),2);
            System.out.println(x +"    "+ y);
        }

        System.out.println("\n");

        for (double x=0; x<=1;x=x+h) {
            y1= 0.25*Math.pow((x*x+x+2),2);
            System.out.println(x +"    "+ y1);
        }


    }
}

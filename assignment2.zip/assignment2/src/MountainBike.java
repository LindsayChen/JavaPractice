/**
 * Created by lindsaychen on 2017-05-30.
 */
public class MountainBike extends Bike {
    public MountainBike(String color, String brand, String condition, String size, double seatHeight) {
        super(color, brand, condition, size);
        this.seatHeight = seatHeight;
    }

    // 3 fields
    private double seatHeight;
    private int yearOfProduce;
    private String name;

    // 2 methods
    public double getSeatHeight() {
        return seatHeight;
    }

    public void setName(String name) {
        this.name = name;
    }

}

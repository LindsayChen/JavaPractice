/**
 * Created by lindsaychen on 2017-06-02.
 */
public interface movable {
    public void accelerate();
    public void decelerate();
}

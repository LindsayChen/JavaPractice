/**
 * Created by lindsaychen on 2017-06-06.
 */
public class MainCar {

    public static void main(String[] args) {
        Car myFirstCar = new Car(2007);
        myFirstCar.checkBatteryStatus();
        int wheels = myFirstCar.numberOfWheels();
        System.out.println("I am a car and I have "+ wheels +" wheels.");
        Engine carEngine = new Engine();
        carEngine.start();
        myFirstCar.setSpeed(50);
        myFirstCar.speedIncrease(20);
        Gearbox carGearbox = new Gearbox();
        carGearbox.gearMode();
        myFirstCar.changeGear();
        Body carBody = new Body();
        carBody.carSeat();
        myFirstCar.speedDecrease(15);
        myFirstCar.changeGear();
        myFirstCar.decelerate();
        myFirstCar.brake();
        carEngine.stop();
    }

}

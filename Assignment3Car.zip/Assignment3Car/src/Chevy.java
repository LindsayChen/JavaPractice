/**
 * Created by lindsaychen on 2017-06-03.
 */
public class Chevy extends Car implements Gasoline, Country{
    private String modelName;
    private Engine engine;

    public Chevy(int year, String model) {
        super(year);
        modelName = model;
    }

    @Override
    public void needGasoline() {
        System.out.println("I need gasoline.");
    }

    @Override
    public String fromCountry() {
        return "USA";
    }

    public static void main(String[] args) {
        Chevy mySonic = new Chevy(2010, "Sonic");
        System.out.println("I am a Sonic." );
        mySonic.needGasoline();
        Engine ChevyEngine = new Engine();
        ChevyEngine.stop();
        String country = mySonic.fromCountry();
        System.out.println("I am a brand from " + country);

    }
}

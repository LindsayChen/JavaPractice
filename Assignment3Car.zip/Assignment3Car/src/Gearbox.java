/**
 * Created by lindsaychen on 2017-06-03.
 */
public class Gearbox {
    public void gearMode(){
        System.out.println("I have 5 gear mode: P N R D L ");
    }

}

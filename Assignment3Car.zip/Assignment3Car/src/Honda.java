/**
 * Created by lindsaychen on 2017-06-06.
 */
public class Honda extends Car implements Gasoline, Country{
    private String modelName;
    private Engine engine;

    public Honda(int year, String model) {
        super(year);
        modelName = model;
    }

    @Override
    public void needGasoline() {
        System.out.println("I don't need gasoline.");
    }

    @Override
    public String fromCountry() {
        return "Japan";
    }

    public static void main(String[] args) {
        Honda myCivic = new Honda(2012, "Civic");
        System.out.println("I am a Civic." );
        myCivic.needGasoline();
        Engine HondaEngine = new Engine();
        HondaEngine.stop();
        String country = myCivic.fromCountry();
        System.out.println("I am a brand from " + country);

    }
}
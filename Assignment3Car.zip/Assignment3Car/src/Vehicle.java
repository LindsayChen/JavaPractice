import java.util.ArrayList;

/**
 * Created by lindsaychen on 2017-06-01.
 */

public class Vehicle implements movable,makingNoise{

    public static void main(String[] args) {
        // some types of vehicle

        ArrayList<String> vehicleTypes = new ArrayList<String>();
        vehicleTypes.add("Car");
        vehicleTypes.add("Bus");
        vehicleTypes.add("Truck");
        vehicleTypes.add("Motorcycle");

        System.out.println("There are " + vehicleTypes.size() + " vehicle types in this list. They are:");

        for (String type:vehicleTypes) {
            System.out.println(type);
        }
    }
    @Override
    public void accelerate() {
        System.out.println("All vehicles can speed up.");
    }

    @Override
    public void decelerate() {
        System.out.println("All vehicles can slow down.");
    }

    @Override
    public void horn() {
        System.out.println("All vehicle can beep.");
    }


}

/**
 * Created by lindsaychen on 2017-06-03.
 */
public class Body {
    private int numberOfSeat =5;

    public void carSeat(){
        System.out.println("I have " + numberOfSeat + " seats. The color of my seats is red.");
    }
}

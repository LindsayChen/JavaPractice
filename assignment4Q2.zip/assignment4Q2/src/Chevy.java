/**
 * Created by lindsaychen on 2017-06-03.
 */
public class Chevy extends Car {
    private String modelName;

    public Chevy(int year, String model) {
        super(year);
        modelName = model;
    }

    public void accelerate() {
        System.out.println("All vehicles can speed up.");
        System.out.println("So I can speed up.");
    }

    public void needGasoline() {
        System.out.println("I need gasoline.");
    }
    public void brake (){
        System.out.println("I stopped.");
    }

    public void checkBatteryStatus() {
        System.out.println("The battery is fully charged and ready to go!");
    }

}

/**
 * Created by lindsaychen on 2017-06-01.
 */

public abstract class Vehicle {

    public abstract void accelerate();

    public abstract void decelerate();

    public void horn() {
        System.out.println("All vehicle can beep.");
    }


}

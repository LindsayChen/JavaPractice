/**
 * Created by lindsaychen on 2017-06-01.
 */
public abstract class Car extends Vehicle {

    public Car(int year) {
        super();
        modelYear = year;
    }

    private int modelYear;
    private double speed;
    private double acceleration;
    private int gear;

    public abstract void brake ();
    public abstract void checkBatteryStatus();

    @Override
    public void horn() {
        super.horn();
    }

//    public void accelerate() {
//        System.out.println("All vehicles can speed up.");
//        System.out.println("So I can speed up.");
//    }

    public void decelerate() {
        System.out.println("All vehicles can slow down.");
        System.out.println("So I can slow down.");
    }
    public void drive(int distanceInMiles){
        System.out.println("Miles driven:" + distanceInMiles + "miles!");
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public void changeGear(){
        if (speed >0 && speed <= 20 ){
            gear = 1;
        }

        else if (speed>20 && speed <=40) {
            gear = 2;
        }

        else if (speed >40 && speed <=65) {
            gear = 3;
        }

        else if (speed >65 && speed <=90) {
            gear = 4;
        }

        else if (speed >90) {
            gear = 5;
        }
        System.out.println("I am in gear " + gear +" of driving mode now.");
    }


}

/**
 * Created by lindsaychen on 2017-06-07.
 */
public class Main {
    public static void main(String[] args) {
        Vehicle myChevy = new Chevy(2010,"Sonic");
        System.out.println("This is myChevy.");
        myChevy.accelerate();
        myChevy.decelerate();
        myChevy.horn();
        Car yourChevy = new Chevy(2016,"Cruze");
        System.out.println("This is yourChevy.");
        yourChevy.accelerate();
        yourChevy.horn();
        yourChevy.setSpeed(50);
        yourChevy.changeGear();
        yourChevy.brake();
        yourChevy.checkBatteryStatus();
        yourChevy.drive(900);
        Chevy herChevy = new Chevy(2017, "Colorado");
        System.out.println("This is herChevy.");
        herChevy.needGasoline();
        herChevy.accelerate();

    }
}

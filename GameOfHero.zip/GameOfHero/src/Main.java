import LingziHeroAttack.*;
import Prasanth_Hero.*;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        System.out.println("Please enter your name:");
        String userName = new Scanner(System.in).nextLine();

        NameList myNameList = new NameList();
        printName(myNameList.getNameList());

        // I only enable 2 heroes for now. As the code is too long, I need to find a better way to write this game.
        System.out.println("\nCurrently, only first two heroes available.\n");

        System.out.println("Please choose your hero by the number:");
        int hero = new Scanner(System.in).nextInt();

        System.out.println("Please choose your enemy by the number:");
        int enemy = new Scanner(System.in).nextInt();

        ActionList myActionList = new ActionList();
        printMove(myActionList.getMoveTypes());

        // constructors for heros and special attack
        Ares myAres = new Ares();
        MeteorFist myMeteorFist = new MeteorFist();
        Athena myAthena = new Athena();
        FireBall myFireBall = new FireBall();
//        Ragnar myRagnar = new Ragnar();
//        AxeThrow myAxeThrow = new AxeThrow();
//        Zephyr myZephyr = new Zephyr();
//        RapidHit myRapidHit = new RapidHit();

        Ares yourAres = new Ares();
        MeteorFist yourMeteorFist = new MeteorFist();
        Athena yourAthena = new Athena();
        FireBall yourFireBall = new FireBall();
//        Ragnar yourRagnar = new Ragnar();
//        AxeThrow yourAxeThrow = new AxeThrow();
//        Zephyr yourZephyr = new Zephyr();
//        RapidHit yourRapidHit = new RapidHit();

        Random r = new Random();
        int h = 1;
        int e = 1;
        do {
            System.out.println("Please choose your move by the number:");
            int action = new Scanner(System.in).nextInt();
            System.out.println(userName+"'s turn:");

            // user's turn
            switch (action) {
                case 1://attack
                    if (enemy == 1) {
                        if (hero == 1) {
                            int amount = r.nextInt(myAres.getDamage())+1;
                            yourAres.receiveDamage(amount);
                            e = yourAres.getHealth();
                            System.out.println("Computer damaged: " + amount + " , " + "health left: " + e);
                        } else if (hero == 2) {
                            int amount = r.nextInt(myAthena.getDamage())+1;
                            yourAres.receiveDamage(amount);
                            e = yourAres.getHealth();
                            System.out.println("Computer damaged: " + amount + " , " + "health left: " + e);
                        }
//                        else if (hero == 3) {
//                            int amount = r.nextInt(myRagnar.getDamage())+1;
//                            yourAres.receiveDamage(amount);
//                            e = yourAres.getHealth();
//                            System.out.println("Computer damaged: " + amount + " , " + "health left: " + e);
//                        }

                    } else if (enemy == 2) {
                        if (hero == 1) {
                            int amount = r.nextInt(myAres.getDamage())+1;
                            yourAthena.receiveDamage(amount);
                            e = yourAthena.getHealth();
                            System.out.println("Computer damaged: " + amount + " , " + "health left: " + e);
                        } else if (hero == 2) {
                            int amount = r.nextInt(myAthena.getDamage())+1;
                            yourAthena.receiveDamage(amount);
                            e = yourAthena.getHealth();
                            System.out.println("Computer damaged: " + amount + " , " + "health left: " + e);
                        }
                    }
                    break;
                case 2://heal
                    if (hero == 1) {
                        int amount = r.nextInt(myAres.getHeal())+1;
                        myAres.heal(amount);
                        h = myAres.getHealth();
                        System.out.println(userName+" healed: " + amount + ", health: " + h);
                    } else if (hero == 2) {
                        int amount = r.nextInt(myAthena.getHeal())+1;
                        myAthena.heal(amount);
                        h = myAthena.getHealth();
                        System.out.println(userName+" healed: " + amount + ", health: " + h);
                    }
                    break;
                case 3://special attack
                    double random = Math.random();
                    if (enemy == 1) {
                        if (hero == 1) {
                            if (random < myMeteorFist.getChanceOfSpecial()) {
                                int amount = r.nextInt(myMeteorFist.getDamageOfSpecial())+1;
                                yourAres.receiveDamage(amount);
                                e = yourAres.getHealth();
                                System.out.println("Computer damaged: " + amount + " , " + "health left: " + e);
                            } else {
                                System.out.println("Computer damaged: 0. Better luck next time.");
                            }
                        } else if (hero == 2) {
                            if (random < myFireBall.getChanceOfSpecial()) {
                                int amount = r.nextInt(myFireBall.getDamageOfSpecial())+1;
                                yourAres.receiveDamage(amount);
                                e = yourAres.getHealth();
                                System.out.println("Computer damaged: " + amount + " , " + "health left: " + e);
                            } else {
                                System.out.println("Computer damaged: 0. Better luck next time.");
                            }
                        }
                    } else if (enemy == 2) {
                        if (hero == 1) {
                            if (random < myMeteorFist.getChanceOfSpecial()) {
                                int amount = r.nextInt(myMeteorFist.getDamageOfSpecial())+1;
                                yourAthena.receiveDamage(amount);
                                e = yourAthena.getHealth();
                                System.out.println("Computer damaged: " + amount + " , " + "health left: " + e);
                            } else {
                                System.out.println("Computer damaged: 0. Better luck next time.");
                            }
                        } else if (hero == 2) {
                            if (random < myFireBall.getChanceOfSpecial()) {
                                int amount = r.nextInt(myFireBall.getDamageOfSpecial())+1;
                                yourAthena.receiveDamage(amount);
                                e = yourAthena.getHealth();
                                System.out.println("Computer damaged: " + amount + " , " + "health left: " + e);
                            } else {
                                System.out.println("Computer damaged: 0. Better luck next time.");
                            }
                        }
                    }
                    break;
            }

            // Computer's turn
            if (h>0 && e>0){
                System.out.println("Computer's turn:");
                int cpuAction = r.nextInt(3)+1;
                System.out.println("Computer's move: "+cpuAction);

                switch (cpuAction) {
                    case 1://attack
                        if (hero == 1) {
                            if (enemy == 1) {
                                int amount = r.nextInt(yourAres.getDamage())+1;
                                myAres.receiveDamage(amount);
                                h = myAres.getHealth();
                                System.out.println(userName+" damaged: " + amount + " , " + "health left: " + h);
                            } else if (enemy == 2) {
                                int amount = r.nextInt(yourAthena.getDamage())+1;
                                myAres.receiveDamage(amount);
                                h = myAres.getHealth();
                                System.out.println(userName+" damaged: " + amount + " , " + "health left: " + h);
                            }
                        } else if (hero == 2) {
                            if (enemy == 1) {
                                int amount = r.nextInt(yourAres.getDamage())+1;
                                myAthena.receiveDamage(amount);
                                h = myAthena.getHealth();
                                System.out.println(userName+" damaged: " + amount + " , " + "health left: " + h);
                            } else if (hero == 2) {
                                int amount = r.nextInt(yourAthena.getDamage())+1;
                                myAthena.receiveDamage(amount);
                                h = myAthena.getHealth();
                                System.out.println(userName+" damaged: " + amount + " , " + "health left: " + h);
                            }
                        }
                        break;
                    case 2://heal
                        if (enemy == 1) {
                            int amount = r.nextInt(yourAres.getHeal())+1;
                            yourAres.heal(amount);
                            e = yourAres.getHealth();
                            System.out.println("Computer healed: " + amount + ", Computer's health: " + e);
                        } else if (enemy == 2) {
                            int amount = r.nextInt(yourAthena.getHeal())+1;
                            yourAthena.heal(amount);
                            e = yourAthena.getHealth();
                            System.out.println("Computer healed: " + amount + ", Computer's health: " + e);
                        }
                        break;
                    case 3://special attack
                        double random = Math.random();
                        if (hero == 1) {
                            if (enemy == 1) {
                                if (random < yourMeteorFist.getChanceOfSpecial()) {
                                    int amount = r.nextInt(yourMeteorFist.getDamageOfSpecial())+1;
                                    myAres.receiveDamage(amount);
                                    h = myAres.getHealth();
                                    System.out.println(userName+" damaged: " + amount + " , " + "health left: " + h);
                                } else {
                                    System.out.println(userName+" damaged: 0. Better luck next time.");
                                }
                            } else if (enemy == 2) {
                                if (random < yourFireBall.getChanceOfSpecial()) {
                                    int amount = r.nextInt(yourFireBall.getDamageOfSpecial())+1;
                                    myAres.receiveDamage(amount);
                                    h = myAres.getHealth();
                                    System.out.println(userName+" damaged: " + amount + " , " + "health left: " + h);
                                } else {
                                    System.out.println(userName+" damaged: 0. Better luck next time.");
                                }
                            }
                        } else if (hero == 2) {
                            if (enemy == 1) {
                                if (random < yourMeteorFist.getChanceOfSpecial()) {
                                    int amount = r.nextInt(yourMeteorFist.getDamageOfSpecial());
                                    myAthena.receiveDamage(amount);
                                    h = myAthena.getHealth();
                                    System.out.println(userName+" damaged: " + amount + " , " + "health left: " + h);
                                } else {
                                    System.out.println(userName+" damaged: 0. Better luck next time.");
                                }
                            } else if (enemy == 2) {
                                if (random < yourFireBall.getChanceOfSpecial()) {
                                    int amount = r.nextInt(yourFireBall.getDamageOfSpecial())+1;
                                    myAthena.receiveDamage(amount);
                                    h = myAthena.getHealth();
                                    System.out.println(userName+" damaged: " + amount + " , " + "health left: " + h);
                                } else {
                                    System.out.println(userName+" damaged: 0. Better luck next time.");
                                }
                            }
                        }
                        break;
                }
            }

        } while (e > 0 && h > 0);

        if (e>h) {
            System.out.println("Computer won!");
        } else {
            System.out.println(userName+" won!");
        }
    }

    // method to print all heros in the NameList
    static void printName(ArrayList<String> nameList){
        for (String heroName:nameList) {
            System.out.println(heroName);
        }
    }

    // method to print all moves in the ActionList
    static void printMove(ArrayList<String> moveTypes){
        for (String move:moveTypes) {
            System.out.println(move);
        }
    }

}

import java.util.ArrayList;

/**
 * Created by lindsaychen on 2017-06-22.
 */
public class ActionList {
    private ArrayList<String> moveTypes = new ArrayList<>();

    public ActionList() {
        moveTypes.add("\n");
        moveTypes.add("1. Attack");
        moveTypes.add("2. Heal");
        moveTypes.add("3. Special attack");
    }

    public ArrayList<String> getMoveTypes() {
        return moveTypes;
    }
}

import LingziHeroAttack.*;
import Prasanth_Hero.AxeThrow;
import Prasanth_Hero.Ragnar;
import Prasanth_Hero.RapidHit;
import Prasanth_Hero.Zephyr;

import java.util.ArrayList;

public class NameList {

    private ArrayList<String> nameList = new ArrayList<>();

    public NameList() {
        // Constructors for Heroes and their specialAttacks
        Ares myAres = new Ares();
        MeteorFist myMeteorFist = new MeteorFist();
        Athena myAthena = new Athena();
        FireBall myFireBall = new FireBall();
        Ragnar myRagnar = new Ragnar();
        AxeThrow myAxeThrow = new AxeThrow();
        Zephyr myZephyr = new Zephyr();
        RapidHit myRapidHit = new RapidHit();


        nameList.add("# "+"  Hero's Name "+"   Health "+" Damage "+" Heal "+"   Special Attack ");
        nameList.add("1.  "+ myAres.getName()+"            "+String.valueOf(myAres.getMaxHealth())+"      "+String.valueOf(myAres.getDamage())+"     "+String.valueOf(myAres.getHeal())+"       "+myMeteorFist.getName());
        nameList.add("2.  "+ myAthena.getName()+"          "+String.valueOf(myAthena.getMaxHealth())+"      "+String.valueOf(myAthena.getDamage())+"     "+String.valueOf(myAthena.getHeal())+"       "+myFireBall.getName());
        nameList.add("3.  "+ myRagnar.getName()+"          "+String.valueOf(myRagnar.getHealth())+"      "+String.valueOf(myRagnar.getDamage())+"     "+String.valueOf(myRagnar.getHeal())+"       "+myAxeThrow.getName());
        nameList.add("4.  "+ myZephyr.getName()+"          "+String.valueOf(myZephyr.getHealth())+"      "+String.valueOf(myZephyr.getDamage())+"     "+String.valueOf(myZephyr.getHeal())+"       "+myRapidHit.getName());

    }

    public ArrayList<String> getNameList() {
        return nameList;
    }
}

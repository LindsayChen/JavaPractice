/**
 * Created by lindsaychen on 2017-05-30.
 */
import java.util.Random;

public class question2 {
    public static void main(String[] args) {
        Random rand = new Random();

        //generate a random byte
        byte b = (byte) rand.nextInt();

        //generate a random short
        short s = (short) rand.nextInt();

        //generate a random integer
        int i = rand.nextInt();

        //divide variables by 2, add them all, and store the result as a long variable
        long result = (long) (b/2 + s/2 + i/2);
        System.out.println(result);

    }
}
/**
 * Created by lindsaychen on 2017-05-30.
 */
public class NewtonRaphson {
    public static void main(String[] args) {
        double f,df,ans1,ans2,e;
        ans1 = 0.5;//initial guesses can be any number

        do{
            f = -1 + 5.5*ans1 - 4*ans1*ans1 +0.5*ans1*ans1*ans1;
            df = 5.5 - 8*ans1 + 1.5*ans1*ans1;
            ans2 = ans1 - f/df;
            e = Math.abs((ans2 - ans1)/ans2);
            ans1 = ans2;
        } while(e > 0.0001);

        System.out.println(ans2);

    }
}

/**
 * Created by lindsaychen on 2017-05-30.
 */
public class Simpson {
    public static void main(String[] args) {
        double I=0;
        double h = 0.75;

        for(int i=0;i<3;i=i+2){
            int j=i+1;
            int k=i+2;
            I = I+h/3*((1-Math.exp(-i*.75)) + 4*(1-Math.exp(-j*.75)) + (1-Math.exp(-k*.75)));
        }
        System.out.println(I);
    }
}

/**
 * Created by lindsaychen on 2017-05-30.
 */
import java.util.Scanner;
public class q5calculator {
    public static void main(String args[]) {
        double a, b, res;
        String input;
        // object creation statement
        Scanner choice = new Scanner(System.in);
        Scanner num1 = new Scanner(System.in);
        Scanner num2 = new Scanner(System.in);

        do {// begin block "do while"
            // method invocation statement
            System.out.println("Option: Add | Subtract | Multiply | Divide | Factorial | Exponentiation | Quit  ");
            input = choice.nextLine();

            switch (input){// begin block "switch"
                case "Add":
                    System.out.println("Enter the first number");
                    a = num1.nextDouble();
                    System.out.println("Enter the second number");
                    b = num2.nextDouble();
                    // a+b is an expression
                    res = a + b;
                    System.out.println("Addition of " + a + " and " + b +" is " +res);
                    break;

                case "Subtract":
                    System.out.println("Enter the first number");
                    a = num1.nextDouble();
                    System.out.println("Enter the second number");
                    b = num2.nextDouble();
                    // a-b is an expression
                    res = a - b;
                    System.out.println("Subtraction of " + a + " by " + b +" is " +res);
                    break;

                case "Multiply":

                    System.out.println("Enter the first number");
                    a = num1.nextDouble();
                    System.out.println("Enter the second number");
                    b = num2.nextDouble();
                    // a*b is an expression
                    res = a * b;
                    System.out.println("Multiplication of " + a + " and " + b +" is " +res);
                    break;

                case "Divide":
                    System.out.println("Enter the first number");
                    a = num1.nextDouble();
                    System.out.println("Enter the second number");
                    b = num2.nextDouble();
                    res = a / b;
                    System.out.println("Division of " + a + " by " + b +" is " +res);
                    break;

                case "Factorial":
                    System.out.println("Enter the number");
                    a = num1.nextDouble();
                    // assignment statement
                    res =1;
                    for(int i = 1; i <= (int)a; i++)
                        res *= i;
                    System.out.println("Factorial of " + a +" is " + res);
                    break;

                case "Exponentiation":
                    System.out.println("Enter the first number");
                    a = num1.nextDouble();
                    System.out.println("Enter the second number");
                    b = num2.nextDouble();
                    res = Math.pow(a,b);
                    System.out.println("Exponential of " + a + " to " + b +" is " +res);
                    break;

                case "Quit":
                    System.out.println("You quit the calculator.");
                    System.exit(0);
                    break;

                default: System.out.println("Your input is invalid!");
                    break;

            }// end block "switch"
            System.out.println("Do you want another operation?");
        } while (!input.equals("Quit"));// end block "do while"

    }
}

/**
 * Created by lindsaychen on 2017-05-30.
 */
public class Trapezoidal {
    public static void main(String[] args) {
        double I=0;
        double h = 1.0;

        for(int i=0;i<3;i++){
            int j=i+1;
            I = I+h/2*((1-Math.exp(-i))+(1-Math.exp(-j)));
        }
        System.out.println(I);
    }
}


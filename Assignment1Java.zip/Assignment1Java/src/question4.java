/**
 * Created by lindsaychen on 2017-05-30.
 */
import java.util.Scanner;

public class question4 {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int sum = 0;
        System.out.println("Enter a number or enter 'exit' to quit:");
        String word = scan.nextLine();

        while (!word.equals("exit")) {
            Integer num = Integer.valueOf(word);
            sum += num;
            System.out.println("Enter a number or enter 'exit' to quit:");
            word = scan.nextLine();
        }
        System.out.println("Sum of the numbers entered = " + sum );

    }

}

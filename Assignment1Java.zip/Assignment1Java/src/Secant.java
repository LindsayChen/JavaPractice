/**
 * Created by lindsaychen on 2017-05-30.
 */
public class Secant {
    public static void main(String[] args) {
        double f0,f1,ans0,ans1,ans2,e;
        //initial guesses can be
        ans0 = 10;
        ans1 = 5;
        do{
            f0 = -1 + 5.5*ans0 - 4*ans0*ans0 +0.5*ans0*ans0*ans0;
            f1 = -1 + 5.5*ans1 - 4*ans1*ans1 +0.5*ans1*ans1*ans1;
            ans2 = ans1 - f1*(ans0-ans1)/(f0-f1);
            e = Math.abs((ans2 - ans1)/ans2);
            ans0 = ans1;
            ans1 = ans2;
        } while(e > 0.0001);

        System.out.println(ans2);

    }
}

/**
 * Created by lindsaychen on 2017-05-30.
 */
import java.util.Scanner;
//Celsius to Fahrenheit converter
public class question3 {
    public static void main(String[] args) {
        double celsius, fahrenheit;
        Scanner c = new Scanner(System.in);
        System.out.println("Enter temperature in Celsius: ");
        celsius = c.nextDouble();
        fahrenheit = (celsius * 9/5) + 32;
        System.out.println("Temperature in Fahrenheit = " + fahrenheit);
    }
}

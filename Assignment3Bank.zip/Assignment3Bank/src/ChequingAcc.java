/**
 * Created by lindsaychen on 2017-06-06.
 */
public class ChequingAcc extends BankAccounts implements ChequingFeatures {
    public ChequingAcc(double initialBalance, int accountNumber, String userName) {
        super(initialBalance, accountNumber, userName);
    }
    private double balance;

    @Override
    public double deposit(double depositAmount) {
        return super.deposit(depositAmount);
    }

    @Override
    public double withdraw(double withdrawAmount) {
        return super.withdraw(withdrawAmount);
    }

    @Override
    public double getBalance() {
        return super.getBalance();
    }

    @Override
    public void transferFromChequingToSavig(BankAccounts SavingAcc, double amount) {
        ChequingAcc.super.withdraw(amount);
        SavingAcc.deposit(amount);
        System.out.println("You have transferred " + amount +" from Chequing account to Saving account.");
    }
}

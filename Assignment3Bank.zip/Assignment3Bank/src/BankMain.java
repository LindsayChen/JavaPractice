/**
 * Created by lindsaychen on 2017-06-01.
 */
import java.util.Scanner;

public class BankMain {

    public static void main(String[] args) {

        // create account objects
        BankUsers User1 = new BankUsers(123456);
        User1.passWord();
        User1.chequingAcc();
        User1.savingAcc();

        SavingAcc S1 = new SavingAcc(10000,1212100,"user1");
        ChequingAcc C1 = new ChequingAcc(20000,1212101,"user1");

        S1.deposit(200);
        S1.getBalance();
        System.out.println("Your new balance is " + S1.getBalance());
        C1.withdraw(100);
        C1.getBalance();
        System.out.println("Your new balance is " + C1.getBalance());

        S1.transferFromSavingToChequing(C1,500);

    }

}

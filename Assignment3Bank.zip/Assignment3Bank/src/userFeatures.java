/**
 * Created by lindsaychen on 2017-06-06.
 */
public interface userFeatures {
    public void passWord();
    public void savingAcc();
    public void chequingAcc();
}

/**
 * Created by lindsaychen on 2017-06-01.
 */
public class BankUsers implements userFeatures {
    private int passWord;

    public BankUsers(int passWord) {
        this.passWord = passWord;
    }

    @Override
    public void passWord() {
        System.out.println("Your default password is " + getPassWord() +". Please change it.");
    }

    @Override
    public void savingAcc() {
        System.out.println("You opened a new Saving Account.");
    }

    @Override
    public void chequingAcc() {
        System.out.println("You opened a new Chequing Account.");
    }

    public int getPassWord() {
        return passWord;
    }
}


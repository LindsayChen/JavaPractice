/**
 * Created by lindsaychen on 2017-06-06.
 */
public interface ChequingFeatures {
    public void transferFromChequingToSavig(BankAccounts Saving, double amount);

}

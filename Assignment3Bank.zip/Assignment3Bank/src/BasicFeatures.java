/**
 * Created by lindsaychen on 2017-06-03.
 */
public interface BasicFeatures {
    public double deposit(double depositAmount);
    public double withdraw(double withdrawAmount);
}

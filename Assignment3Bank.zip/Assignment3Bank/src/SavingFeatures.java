/**
 * Created by lindsaychen on 2017-06-06.
 */
public interface SavingFeatures {
    public void transferFromSavingToChequing(BankAccounts Chequing, double amount);
}

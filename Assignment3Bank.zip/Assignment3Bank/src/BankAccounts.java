/**
 * Created by lindsaychen on 2017-06-01.
 */
public class BankAccounts implements BasicFeatures{
    private double balance;
    private int accountNumber;
    private String userName;


    // constructor to initialize the account
    public BankAccounts(double initialBalance, int accountNumber, String userName) {
        balance = initialBalance;
        this.accountNumber = accountNumber;
        this.userName = userName;
    }

    public double getBalance() {
        return balance;
    }

    @Override
    // method to deposit to the account
    public double deposit(double depositAmount) {
        balance += depositAmount;
        return balance;
    }

    @Override
    // method to withdraw from the account
    public double withdraw(double withdrawAmount) {
        balance -= withdrawAmount;
        return balance;
    }

}

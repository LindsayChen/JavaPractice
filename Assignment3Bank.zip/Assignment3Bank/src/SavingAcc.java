/**
 * Created by lindsaychen on 2017-06-06.
 */
public class SavingAcc extends BankAccounts implements SavingFeatures {
    public SavingAcc(double initialBalance, int accountNumber, String userName) {
        super(initialBalance, accountNumber, userName);
    }


    @Override
    public double getBalance() {
        return super.getBalance();
    }

    @Override
    public double deposit(double depositAmount) {
        return super.deposit(depositAmount);
    }

    @Override
    public double withdraw(double withdrawAmount) {
        return super.withdraw(withdrawAmount);
    }

    @Override
    public void transferFromSavingToChequing(BankAccounts ChequingAcc, double amount) {
        SavingAcc.super.withdraw(amount);
        ChequingAcc.deposit(amount);
        System.out.println("You have transferred " + amount +" from Saving account to Chequing account.");
    }
}

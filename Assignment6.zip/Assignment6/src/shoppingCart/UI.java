package shoppingCart;

import java.util.List;
import java.util.Scanner;

/**
 *interaction between the user and application
 */
public class UI {
    private Cart mycart = new Cart();
    private int ch = 0;
    private  String input =null;

    public UI () {
        menu();
    }

    public void startScreen() {
        System.out.println(
                "1.Display Store Items\n"+
                "2.Display Cart\n"+
                "0.Exit");
    }

    public void storeItemsMenu() {
        System.out.println(
                "1.Add to Cart\n"+
                "2.Remove from Cart\n"+
                "3.Search through cart\n"+
                "0.Exit");
    }

    public void menu() {
        do {
            startScreen();
            getUserInput1();

            switch (ch) {
                case 1:
                    displayStoreItems();
                    storeItemsMenu();
                    getUserInput1();
                    innerChoice1();
                    break;
                case 2:
                    showCart();
                    break;
                case 0:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid input. Try again.");
                    break;
            }
        } while (ch !=0);
    }

    private void innerChoice1() {
        switch (ch) {
            case 1:
                addItemtoCart();
                showCart();
                break;
            case 2:
                removeItemFromCart();
                showCart();
                break;
            case 3:
                searchItem();
                break;
            case 0:
                System.exit(0);
                break;
            default:
                System.out.println("Invalid input. Try again.");
                break;
        }
    }

    private void getUserInput1() {
        System.out.println("Type your choice by the number:");
        Scanner in = new Scanner(System.in);
        ch = Integer.parseInt(in.nextLine());
    }

    private String getUserInput2() {
        System.out.println("Type the item name:");
        Scanner in = new Scanner(System.in);
        input = in.nextLine();
        return input;
    }

    private void displayStoreItems() {
        System.out.println("Here are the items in store:");
        List<Item> items = new Items().getItems();
        for(Item it:items) {
            System.out.println(it.getName());
        }
    }

    private void addItemtoCart() {
        String name = getUserInput2();
        mycart.addItemToCartByName(name);
    }

    private void showCart() {
        mycart.printCartItems();
    }

    private void removeItemFromCart() {
        String name = getUserInput2();
        mycart.removeItemByName(name);
    }

    private void searchItem() {
        String searchedName =getUserInput2();
        mycart.searchItemByName(searchedName);
    }
}

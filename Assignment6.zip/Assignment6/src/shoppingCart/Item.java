package shoppingCart;

/**
 * class which contains item properties and provides setters and getters
 */
public class Item implements Comparable<Item>{
    private String name;
    private boolean existed = false;


    public Item(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }


    @Override
    public int compareTo(Item item) {
        return this.name.compareToIgnoreCase(item.name);
    }

    public boolean existed () {
        if (this.existed) {
            return false;
        }
        this.existed=true;
        return true;
    }
}

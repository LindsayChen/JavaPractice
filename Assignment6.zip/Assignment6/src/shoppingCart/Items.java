package shoppingCart;

import java.util.ArrayList;
import java.util.List;

/**
 * class to provide the store products, and to initialize the store
 */
public class Items {
    private final List<Item> items = new ArrayList<Item>();

    public Items() {
        this.initStoreItems();
    }

    public List<Item> getItems() {
        return items;
    }

    public void initStoreItems() {
        String [] itemNames = {"Milk","Bread","Chocolate",
                "Apple","Orange","Banana"};
        for (int i=0;i<itemNames.length;i++) {
            this.items.add(new Item(itemNames[i]));
        }
    }
}

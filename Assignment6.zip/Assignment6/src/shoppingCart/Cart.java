package shoppingCart;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * class to put the items into the cart
 */
public class Cart {
    private List<Item> cartItems = new ArrayList<>();

    private Item getItemByItemName(String name) {
        Item item = null;
        List<Item> items = new Items().getItems();
        for (Item it:items) {
            if (it.getName().equals(name)) {
                item = it;
                break;
            }
        }
        return item;
    }

    public void addItemToCartByName(String name) {
        Item item = getItemByItemName(name);
        cartItems.add(item);
    }

    public void removeItemByName(String name) {
        Item item = null;
        for (Item it: cartItems) {
            if (it.getName().equals(name)) {
                item = it;
                break;
            }
        }
        cartItems.remove(item);
    }

    void printCartItems() {
        System.out.println("Here are the items in your cart:");
        for (Item it: cartItems) {
            System.out.println(it.getName());
        }
    }

    public boolean searchItemByName (String SearchedName) {

        Item temp = new Item(SearchedName);
        int index = Collections.binarySearch(cartItems,temp,null);

        if (index>=0) {
            System.out.println("This item is in your cart.");
            return cartItems.get(index).existed();
        }
        System.out.println("This item is NOT found in your cart.");
        return false;
    }

}

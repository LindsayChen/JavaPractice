package shoppingCart;

/**
 * Created by lindsaychen on 2017-07-06.
 */
public class Main {
    public static void main(String[] args) {
        new UI();
    }
}

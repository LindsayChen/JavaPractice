package phoneBook;

import java.util.*;

/**
 * class has all functions which works for this program
 */
public class PhoneBook {
    private HashMap<String,Integer> phoneBook = new HashMap<>();
//    Scanner input = new Scanner(System.in);
    private int choice = 0;

    public PhoneBook() {
        phoneBook.put("Alex",27826772);
        phoneBook.put("John",28926772);
        menu();
    }

    public void startScreen() {
        System.out.println(
                "1.Show All Contact\n"
                +"2.Search Name\n"
                +"3.Search Number\n"
                +"4.Add Contact\n"
                +"5.Delete Contact\n"
                +"6.Modify Contact\n"
                +"0.Exit");
    }

    public void menu() {
        do {
            startScreen();
            getUserChoice();

            switch (choice) {
                case 1:
                    showAll();
                    break;
                case 2:
                    searchName();
                    break;
                case 3:
                    searchNumber();
                    break;
                case 4:
                    addContact();
                    break;
                case 5:
                    deleteContact();
                    break;
                case 6:
                    modifyContact();
                    break;
                case 0:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid Input");
                    break;
            }
            System.out.println("Type your choice by the number:");
        } while (choice!=0);
    }

    private void showAll() {
        for(String name:phoneBook.keySet()) {
            if(name!=null) {
                System.out.println(name+" "+phoneBook.get(name));
            }else {
                System.out.println("Empty phone book.");
            }
        }
    }

    private void searchNumber() {
        System.out.println("Type the name:");
        Scanner input = new Scanner(System.in);
        String name = input.next();
        System.out.println(phoneBook.containsKey(name)?"The number of "
                +name+" is:"+phoneBook.get(name):"The number of"+name
                +"does not exist.");
    }

    private void searchName() {
        System.out.println("Type the number:");
        Scanner input = new Scanner(System.in);
        int number = input.nextInt();
        System.out.println(phoneBook.containsValue(number)?"The name of "
                +number+" is:"+PhoneBook.getKeyByValue(phoneBook,number):"The name of"+number
                +"does not exist.");

    }

    private void addContact() {
        System.out.println("Type the name to add contact:");
        Scanner input = new Scanner(System.in);
        String name = input.next();
        System.out.println("Type the number:");
        int number = input.nextInt();
        phoneBook.put(name,number);
        System.out.println("New Contact added.");
    }

    private void deleteContact() {
        System.out.println("Type the name to delete contact:");
        Scanner input = new Scanner(System.in);
        String name = input.next();
        if (phoneBook.containsKey(name)) {
            phoneBook.remove(name);
            System.out.println("The number of "+name+" is removed.");
        } else {
            System.out.println("The number of"+name+"does not exist.");
        }
    }

    private void modifyContact() {
        System.out.println("Type the name of contact to modify:");
        Scanner input = new Scanner(System.in);
        String name = input.next();
        if (phoneBook.containsKey(name)){
            int oldNumber = phoneBook.get(name);
            System.out.println("Type the new number to modify:");
            int newNumber = input.nextInt();
            if (phoneBook.containsValue(oldNumber)) {
                phoneBook.remove(name);
                phoneBook.put(name,newNumber);
                System.out.println("The number of "+name+"is updated to "+ newNumber);
            }
        }else {
            System.out.println(name+" does not exist.");
        }

    }

    private static Object getKeyByValue(HashMap phoneBook, Object value) {
        for (Object o : phoneBook.keySet()) {
            if (phoneBook.get(o).equals(value)) {
                return o;
            }
        }
        return null;
    }

    private void getUserChoice() {
        System.out.println("Type your choice by the number:");
        Scanner input = new Scanner(System.in);
        choice = input.nextInt();
    }

}

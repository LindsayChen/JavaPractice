package listOfNumbers;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ArrayList<String> numberList = new ArrayList<String>();
        numberList.add("1");
        numberList.add("2");
        numberList.add("3");
        numberList.add("4");
        System.out.println("The original list: "+numberList);
        System.out.println("Enter the number to put in the list: type done to finish ");
        Scanner scanner = new Scanner(System.in);
        String userInput = scanner.next();

        while (!userInput.equals("done")) {
            numberList.add(userInput);
            System.out.println("Enter the numbers: type done to finish ");
            userInput = scanner.next();
        }
        System.out.println("Here is the new list: "+numberList);

        System.out.println("1.Find min and max\n" +
                "2.Search for a number\n"+
                "3.Reverse order\n"+
                "4.Shuffle numbers\n"+
                "5.Sort numbers\n"+
                "6.Exit\n"+
                "Enter your choice by number:");
        int ch = scanner.nextInt();

        while (ch!=0){
            switch (ch) {
                case 1:
                    System.out.println("max: "+ Collections.max(numberList));
                    System.out.println("min: "+ Collections.min(numberList));
                    break;
                case 2:
                    System.out.println("Type the number you are searching:");
                    String searchedNumber = scanner.next();
                    int index = Collections.binarySearch(numberList,searchedNumber);
                    if (index>=0) {
                        System.out.println("The index of the number is: "+index);
                    }
                    System.out.println("Couldn't find the number.");
                    break;
                case 3:
                    Collections.reverse(numberList);
                    System.out.println("list in reverse order: "+numberList);
                    break;
                case 4:
                    Collections.shuffle(numberList);
                    System.out.println("Shuffle the numbers: "+numberList);
                    break;
                case 5:
                    Collections.sort(numberList);
                    System.out.println("Sort the numbers: "+numberList);
                    break;
                case 6:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid input. Try again.");
                    break;
            }

            System.out.println("1.Find min and max\n" +
                    "2.Search for a number\n"+
                    "3.Reverse order\n"+
                    "4.Shuffle numbers\n"+
                    "5.Sort numbers\n"+
                    "6.Exit\n"+
                    "Enter your choice by number:");
            ch = scanner.nextInt();
        }
    }
}



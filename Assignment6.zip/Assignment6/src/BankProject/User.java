package BankProject;

import java.util.ArrayList;

public class User {
    String userName;
    int userId;

    public User(String userName, int userId) {
        this.userName = userName;
        this.userId = userId;
    }
}

package BankProject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();
        accounts.add(new BankAccount("CAD Saving Account",0001,5000));
        accounts.add(new BankAccount("US Saving Account ",0002,4000));
        accounts.add(new BankAccount("CAD Chequing Account",0003,1000));
        accounts.add(new BankAccount("US Chequing Account",0004,2000));
        accounts.add(new BankAccount("CAD Credit Account",0005,0));
        accounts.add(new BankAccount("US Credit Account",0006,0));

        for (BankAccount account:accounts) {
            System.out.println(account.accountName);
        }

        ArrayList<User> users = new ArrayList<User>();
        users.add(new User("John", 1233));
        users.add(new User("Peter", 5354));
        users.add(new User("Leo", 1523));
        users.add(new User("Sam", 1283));
        users.add(new User("Lucy", 1023));

        for (User user:users) {
            System.out.println(user.userName);
        }

    }
}

package BankProject;

public class BankAccount {
    String accountName;
    int accountNum;
    double balance;

    public BankAccount(String accountName, int accountNum, double balance) {
        this.accountName = accountName;
        this.accountNum = accountNum;
        this.balance = balance;
    }

    public int getAccountNum() {
        return accountNum;
    }

    public double deposit(double depositAmount) {
        balance += depositAmount;
        return balance;
    }

    public double withdraw(double withdrawAmount) {
        balance -= withdrawAmount;
        return balance;
    }

}

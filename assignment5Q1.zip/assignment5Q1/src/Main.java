
import java.util.Scanner;
public class Main {
    static Button myButton1 = new Button("Button 1 ", "checking");
    static Button myButton2 = new Button("Button 2 ", "printing");
    static Button myButton3 = new Button("Button 3 ", "cleaning");

    class Listener implements IListener{
        public void onClick(){
            System.out.println("You clicked me!");
        }
    }

    public static void main(String args[]) {
        String input;
        Scanner choice = new Scanner(System.in);

        do {
            System.out.println("Please enter the number of the corresponding button:\n(You can type 'Quit' to quit the program.)");
            input = choice.next();

            switch (input){
                case "1":
                    myButton1.setListener(new IListener() {
                        @Override
                        public void onClick() {
                            System.out.println("You clicked me to check.\n");
                        }
                    });
                    myButton1.click();
                    break;

                case "2":
                    myButton2.setListener(new IListener() {
                        @Override
                        public void onClick() {
                            System.out.println("You clicked me to print.\n");
                        }
                    });
                    myButton2.click();
                    break;

                case "3":
                    myButton3.setListener(new IListener() {
                        @Override
                        public void onClick() {
                            System.out.println("You clicked me to clean.\n");
                        }
                    });
                    myButton3.click();
                    break;

                case "Quit":
                    System.out.println("You quit the button clicker.");
                    System.exit(0);
                    break;

                default: System.out.println("Your input is invalid!\n");
                    break;

            }
            System.out.println("Do you want to try again?");
        }while (!input.equals("Quit"));
    }

}


public class Button {
    String name;
    String text;
    IListener listener;

    public Button(String name, String text) {
        this.name = name;
        this.text = text;
    }

    public void setListener(IListener listener) {
        this.listener = listener;
    }

    void click(){
        listener.onClick();
    }

}

interface IListener{
    void onClick();
}

import LingziHeroAttack.*;
import DisHeros.*;
import Prasanth_Hero.*;
import WilliamImports.*;
import com.Jetbrains.*;
import required.Hero;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Hero chosenHero;
        Hero chosenEnemy;
        Random r = new Random();

        System.out.println("Please enter your name:");
        String userName = new Scanner(System.in).nextLine();

        NameList myNameList = new NameList();
        printName(myNameList.getNameList());


        System.out.println("Please choose your hero by the number:");
        chosenHero = chooseHero();

        System.out.println("Please choose your enemy by the number:");
        chosenEnemy = chooseHero();

        ActionList myActionList = new ActionList();
        printMove(myActionList.getMoveTypes());

        //hero life
        int heroHealth = 1;
        int enemyHealth = 1;
        do {
            System.out.println("Please choose your move by the number:");
            int action = new Scanner(System.in).nextInt();
            System.out.println(userName+"'s turn:");

            // user's turn
            switch (action) {
                case 1://attack
                    int amount = r.nextInt(chosenHero.getDamage())+1;
                    chosenEnemy.receiveDamage(amount);
                    enemyHealth = chosenEnemy.getHealth();
                    System.out.println("Computer damaged: " + amount + " , " + "health left: " + enemyHealth);
                    break;
                case 2://heal
                    amount = r.nextInt(chosenHero.getHeal())+1;
                    chosenHero.heal(amount);
                    heroHealth = chosenHero.getHealth();
                    System.out.println(userName+" healed: " + amount + ", health: " + heroHealth);
                    break;
                case 3://special attack
                    double random = Math.random();
                    if (random < chosenHero.getSpecialAttack().getChanceOfSpecial()) {
                        amount = r.nextInt(chosenHero.getSpecialAttack().getDamageOfSpecial())+1;
                        chosenEnemy.receiveDamage(amount);
                        enemyHealth = chosenEnemy.getHealth();
                        System.out.println("Computer damaged: " + amount + " , " + "health left: " + enemyHealth);
                    } else {
                        System.out.println("Computer damaged: 0. Better luck next time.");
                    }
                    break;
            }
            // Computer's turn
            if (heroHealth>0 && enemyHealth>0){
                System.out.println("Computer's turn:");
                int cpuAction = r.nextInt(3)+1;
                System.out.println("Computer's move: "+cpuAction);

                switch (cpuAction) {
                    case 1://attack
                        int amount = r.nextInt(chosenEnemy.getDamage())+1;
                        chosenHero.receiveDamage(amount);
                        heroHealth = chosenHero.getHealth();
                        System.out.println(userName+" damaged: " + amount + " , " + "health left: " + heroHealth);
                        break;
                    case 2://heal
                        amount = r.nextInt(chosenEnemy.getHeal())+1;
                        chosenEnemy.heal(amount);
                        enemyHealth = chosenEnemy.getHealth();
                        System.out.println("Computer healed: " + amount + ", health: " + enemyHealth);
                        break;
                    case 3://special attack
                        double random = Math.random();
                        if (random < chosenEnemy.getSpecialAttack().getChanceOfSpecial()) {
                            amount = r.nextInt(chosenEnemy.getSpecialAttack().getDamageOfSpecial())+1;
                            chosenHero.receiveDamage(amount);
                            heroHealth = chosenHero.getHealth();
                            System.out.println(userName+" damaged: " + amount + " , " + "health left: " + heroHealth);
                        } else {
                            System.out.println(userName+" damaged: 0. Better luck next time.");
                        }
                        break;
                }
            }

        } while (enemyHealth > 0 && heroHealth > 0);

        if (enemyHealth>heroHealth) {
            System.out.println("Computer won!");
        } else {
            System.out.println(userName+" won!");
        }
    }

    // method to choose hero characters
    private static Hero chooseHero() {
        int heroNumber = new Scanner(System.in).nextInt();
        switch (heroNumber) {
            case 1:
                return new Ares();
            case 2:
                return new Athena();
            case 3:
                return new Ragnar();
            case 4:
                return new Zephyr();
            case 5:
                return new Charizard();
            case 6:
                return new Mewtwo();
            case 7:
                return new Bowser();
            case 8:
                return new Illidan();
// I tried to import others' heroes into the library, but these heroes didn't work.
// I think they didn't import Hero into the library in their jar files.
//            case 9:
//                return new BananaSlamJamma();
//            case 10:
//                return new ChiLongQua();
//            case 11:
//                return new Azura();
//            case 12:
//                return new Dancer();
//            case 13:
//                return new Dionysus();
//            case 14:
//                return new Fortuna();
//            case 15:
//                return new Falco();
//            case 16:
//                return new Fox();
//            case 17:
//                return new Goku();
//            case 18:
//                return new Itachi();
//            case 19:
//                return new Goku();
//            case 20:
//                return new Vegeta();
//            case 21:
//                return new Hercules();
//            case 22:
//                return new Kratos();
            default:
                return new Ares();
        }
    }

    // method to print all heros in the NameList
    static void printName(ArrayList<String> nameList){
        for (String heroName:nameList) {
            System.out.println(heroName);
        }
    }

    // method to print all moves in the ActionList
    static void printMove(ArrayList<String> moveTypes){
        for (String move:moveTypes) {
            System.out.println(move);
        }
    }

}

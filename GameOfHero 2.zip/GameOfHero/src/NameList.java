import DisHeros.*;
import LingziHeroAttack.*;
import Prasanth_Hero.*;
import WilliamImports.*;

import java.sql.PseudoColumnUsage;
import java.util.ArrayList;

public class NameList {

    private ArrayList<String> nameList = new ArrayList<>();

    public NameList() {

        // Constructors for Heroes and their specialAttacks
        Ares myAres = new Ares();
        MeteorFist myMeteorFist = new MeteorFist();
        Athena myAthena = new Athena();
        FireBall myFireBall = new FireBall();
        Ragnar myRagnar = new Ragnar();
        AxeThrow myAxeThrow = new AxeThrow();
        Zephyr myZephyr = new Zephyr();
        RapidHit myRapidHit = new RapidHit();
        Charizard myCharizard = new Charizard();
        Flame myFlame = new Flame();
        Mewtwo myMewtwo = new Mewtwo();
        Psystrike myPsystrike = new Psystrike();
        Bowser myBowser = new Bowser();
        FireBreath myFireBreath = new FireBreath();
        Illidan myIllidan = new Illidan();
        SoulBurn myASoulBurn = new SoulBurn();


        nameList.add("# "+"  Hero's Name "+"       Health "+" Damage "+" Heal "+"   Special Attack ");
        nameList.add("1.  "+ myAres.getName()+"                "+String.valueOf(myAres.getMaxHealth())+"      "+String.valueOf(myAres.getDamage())+"     "+String.valueOf(myAres.getHeal())+"       "+myMeteorFist.getName());
        nameList.add("2.  "+ myAthena.getName()+"              "+String.valueOf(myAthena.getMaxHealth())+"      "+String.valueOf(myAthena.getDamage())+"     "+String.valueOf(myAthena.getHeal())+"       "+myFireBall.getName());
        nameList.add("3.  "+ myRagnar.getName()+"              "+String.valueOf(myRagnar.getMaxHealth())+"      "+String.valueOf(myRagnar.getDamage())+"     "+String.valueOf(myRagnar.getHeal())+"       "+myAxeThrow.getName());
        nameList.add("4.  "+ myZephyr.getName()+"              "+String.valueOf(myZephyr.getMaxHealth())+"      "+String.valueOf(myZephyr.getDamage())+"     "+String.valueOf(myZephyr.getHeal())+"       "+myRapidHit.getName());
        nameList.add("5.  "+ myCharizard.getName()+"           "+String.valueOf(myCharizard.getMaxHealth())+"      "+String.valueOf(myCharizard.getDamage())+"     "+String.valueOf(myCharizard.getHeal())+"       "+myFlame.getName());
        nameList.add("6.  "+ myMewtwo.getName()+"              "+String.valueOf(myMewtwo.getMaxHealth())+"      "+String.valueOf(myMewtwo.getDamage())+"     "+String.valueOf(myMewtwo.getHeal())+"       "+myPsystrike.getName());
        nameList.add("7.  "+ myBowser.getName()+"              "+String.valueOf(myBowser.getHealth())+"      "+String.valueOf(myBowser.getDamage())+"     "+String.valueOf(myBowser.getHeal())+"       "+myFireBreath.getName());
        nameList.add("8.  "+ myIllidan.getName()+"   "+String.valueOf(myIllidan.getHealth())+"       "+String.valueOf(myIllidan.getDamage())+"     "+String.valueOf(myIllidan.getHeal())+"       "+myASoulBurn.getName());


    }

    public ArrayList<String> getNameList() {
        return nameList;
    }
}

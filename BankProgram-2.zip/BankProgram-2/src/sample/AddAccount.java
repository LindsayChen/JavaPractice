package sample;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;

public class AddAccount {

    @FXML
    ComboBox<String> accountType;
}

package sample;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;


public class Withdraw {

    @FXML
    TextField amount;

//    @FXML
//    Button submit;

    @FXML
    Label error;

//    @FXML
//    private void checkFields(){
//        if(amount.getText().isEmpty()){
//            submit.setDisable(true);
//        } else{
//            submit.setDisable(false);
//        }
//    }
//
//    @FXML
//    private void submit() {
//            try{
//                Parent root = FXMLLoader.load(getClass().getResource("account.fxml"));
//                Scene Account = new Scene(root,500,400);
//                Main.getTheStage().setScene(Account);}
//            catch (Exception e){
//                System.out.println(e.getStackTrace());
//            }
//    }
}

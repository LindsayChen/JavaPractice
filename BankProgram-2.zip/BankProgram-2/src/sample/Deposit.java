package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;

import java.io.IOException;
import java.util.Optional;


public class Deposit {

    @FXML
    TextField amount;

    @FXML
    Button submit;

    @FXML
    Label error;

//    @FXML
//    private void checkFields(){
//        if(amount.getText().isEmpty()){
//            submit.setDisable(true);
//        } else{
//            submit.setDisable(false);
//        }
//    }
//
//    @FXML
//    private void submit() {
//            try{
//                Parent root = FXMLLoader.load(getClass().getResource("account.fxml"));
//                Scene Account = new Scene(root,500,400);
//                Main.getTheStage().setScene(Account);}
//            catch (Exception e){
//                System.out.println(e.getStackTrace());
//            }
//    }
}

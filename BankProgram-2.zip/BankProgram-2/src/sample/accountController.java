package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;

import java.io.IOException;
import java.util.Optional;

public class accountController {

    User user;
    Account account;

    @FXML
    ListView<Account> accounts;

    @FXML
    TextArea userInfo;

    @FXML
    TextArea accountInfo;

    @FXML
    Button Deposit;

    @FXML
    Button Withdraw;

    @FXML
    Label error;

    public void initialize(){
        user = Database.getUser();
        accounts.getItems().addAll(user.getAccounts());
//        Deposit.setDisable(true);
//        Withdraw.setDisable(true);
    }


    @FXML
    private void showUserInfo(){
        userInfo.setText("Name: " + user.getName()+"\n"+"Phone: "
                + user.getPhoneNumber()+"\n"+"Address: " +
                user.getAddress()+"\n");
    }

    @FXML
    private void showAccountInfo(){
        accountInfo.setText("balance: " + accounts.getSelectionModel().getSelectedItem().getBalance());

    }

    @FXML
    private void deleteAccount(){
        user.getAccounts().remove(accounts.getSelectionModel().getSelectedItem());
        updateListview();
    }


    private void updateListview(){
        accounts.getItems().clear();
        accounts.getItems().addAll(user.getAccounts());
    }

    @FXML
    private void logOut(){

        Main.getTheStage().setTitle("Login");
        Main.getTheStage().setScene(Main.getLoginScene());
        FXMLLoader fxmlLoader = new FXMLLoader();
        try{
            Main.getLoginScene().setRoot(fxmlLoader.load(getClass().getResource("Login.fxml")));
        }
        catch (IOException e){
            e.getStackTrace();
        }
    }

    @FXML
    private void showAddAccount(){
        Dialog<ButtonType> addAccountDialog = new Dialog<>();
        addAccountDialog.initOwner(Main.getTheStage());
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("addAccount.fxml"));
        try{
            addAccountDialog.getDialogPane().setContent(fxmlLoader.load());}
        catch (IOException e){}
        addAccountDialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        addAccountDialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = addAccountDialog.showAndWait();

        if(result.get() == ButtonType.OK && result.isPresent()){
            AddAccount controller = fxmlLoader.getController();
            if(controller.accountType.getValue().equals("Saving")){
                user.addAccount(new SavingsAccount());
            } else if(controller.accountType.getValue().equals("Chequing")){
                user.addAccount(new ChequingAccount());
            }
        }
        updateListview();

    }

//    @FXML
//    private void checkClick(){
//        if(accounts.getSelectionModel().isEmpty()){
//            Deposit.setDisable(true);
//            Withdraw.setDisable(true);
//        } else{
//            Deposit.setDisable(false);
//            Withdraw.setDisable(false);
//        }
//    }


    @FXML
    private void showDeposit() {
        Dialog<ButtonType> addDepositDialog = new Dialog<>();
        addDepositDialog.initOwner(Main.getTheStage());
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("deposit.fxml"));
        try{
            addDepositDialog.getDialogPane().setContent(fxmlLoader.load());
            }
        catch (IOException e){}
        addDepositDialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        addDepositDialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = addDepositDialog.showAndWait();

        if(result.get() == ButtonType.OK && result.isPresent()){
            Deposit controller = fxmlLoader.getController();
            accounts.getSelectionModel().getSelectedItem().deposit(Double.parseDouble(controller.amount.getText()));
        }
        updateListview();
    }


    @FXML
    private void showWithdraw() {
        Dialog<ButtonType> addWithdrawDialog = new Dialog<>();
        addWithdrawDialog.initOwner(Main.getTheStage());
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("withdraw.fxml"));
        try{
            addWithdrawDialog.getDialogPane().setContent(fxmlLoader.load());
        }
        catch (IOException e){}
        addWithdrawDialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        addWithdrawDialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);

        Optional<ButtonType> result = addWithdrawDialog.showAndWait();

        if(result.get() == ButtonType.OK && result.isPresent()){
            Withdraw controller = fxmlLoader.getController();
            accounts.getSelectionModel().getSelectedItem().withdraw(Double.parseDouble(controller.amount.getText()));
        }
        updateListview();
    }

}

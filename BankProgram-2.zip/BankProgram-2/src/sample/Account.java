package sample;

import java.util.Random;

public abstract class Account {

    private double balance;
    private int id;

    Account(){
        Random rand = new Random();
        this.balance = balance;
        id = rand.nextInt(900000) + 100000;
    }

    public double getBalance() {
        return balance;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        if(this.getClass().isInstance(new SavingsAccount())){
            return "saving-"+getId();
        }
        else if(this.getClass().isInstance(new ChequingAccount())){
            return "chequing-"+getId();
        }
        return "" + getId();

    }

    public double deposit(double depositAmount) {
        balance += depositAmount;
        return balance;
    }

    public double withdraw(double withdrawAmount) {
        if (withdrawAmount<=balance) {
            balance -= withdrawAmount;
        } else {
            System.out.println("Insufficient amount!");
        }
        return balance;
    }
}

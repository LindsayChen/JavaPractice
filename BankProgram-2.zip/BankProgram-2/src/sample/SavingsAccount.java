package sample;

public class SavingsAccount extends Account {



    SavingsAccount(){}
}

package sample;

public class ChequingAccount extends Account {

    public ChequingAccount() {
    }
}

/**
 * Created by lindsaychen on 2017-06-03.
 */
/*
Make a phone class that has 2 inner classes inside it.
One CPU class that is public and one memory class that would
be private. "Make appropriate getters and setters for other
classes to access the memory." In your main method, create one
CPU first, then create one phone and use setter method to
put the CPU inside your phone.
 */
public class Phone {

    private String model;
    private String ownerName;
    CPU cpu;
    Memory memory;

    public class CPU {
        double price;
        String model;

        public CPU(double price, String model) {
            this.price = price;
            this.model = model;
        }

    }

    public void setCpu(CPU cpu) {
        this.cpu = cpu;
    }

    private class Memory {
        int size;

        public Memory(int size) {
            this.size = size;
        }
    }

    public Memory getMemory() {
        return memory;
    }

    public void setMemory(Memory memory) {
        this.memory = memory;
    }
}


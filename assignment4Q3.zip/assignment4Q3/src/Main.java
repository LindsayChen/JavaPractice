/**
 * Created by lindsaychen on 2017-06-08.
 */
public class Main {
    public static void main(String[] args) {
        Phone.CPU myCpu = new Phone().new CPU(500,"Intel");
        Phone myPhone = new Phone();
        myPhone.setCpu(myCpu);
        System.out.println("Price of the CPU: " + myPhone.cpu.price);
    }
}

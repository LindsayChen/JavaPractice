/**
 * Created by lindsaychen on 2017-06-02.
 */
public interface makingNoise {
    public void horn();
}

/**
 * Created by lindsaychen on 2017-06-03.
 */
public class Chevy extends Car implements Gasoline, Country {
    private String modelName;
    private Engine engine;

    public Chevy(int year, String model) {
        super(year);
        modelName = model;
    }

    @Override
    public void needGasoline() {
        System.out.println("I have 70% gasoline.");
    }

    @Override
    public String fromCountry() {
        return "USA";
    }

    @Override
    public void checkBatteryStatus() {
        super.checkBatteryStatus();
    }

    public void Country() {
        Chevy mySonic = new Chevy(2010, "Sonic");
        String country = mySonic.fromCountry();
        System.out.println("I am a Sonic made in 2010 and I am a brand from " + country);
    }

    public static void main(String[] args) {
        Engine ChevyEngine = new Engine();
        ChevyEngine.stop();
    }
}

import java.util.*;
public class WheelOfFortune {
    public static void main(String[] args) {
        String input;
        Scanner choice = new Scanner(System.in);

        do {
            System.out.println("You have entered a Wheel of Fortune. Please spin the wheel:\n(You can type 'Spin' to do so, or You can type 'Quit' to quit the program.)");
            input = choice.next();

            if (input.equals("Spin")) {
                //make a random model

                Random r = new Random();
                int result = r.nextInt(3);

                if (result == 0) {
                    Ford myCar;
                    myCar = new Ford(2010, "Focus");
                    int input2;
                    Scanner choice2 = new Scanner(System.in);
                    do {
                        ArrayList<String> Functions = new ArrayList<String>();
                        Functions.add("Introduction");
                        Functions.add("Check Gasoline");
                        Functions.add("Check Battery");
                        Functions.add("Horn");
                        Functions.add("Miles Driven");
                        Functions.add("Brake");
                        Functions.add("Quit");
                        System.out.println("You have randomly picked a car.\nHere are some basic functions:\n (Please type in the function number)");
                        for (String type:Functions) {
                            System.out.println("*"+Functions.indexOf(type)+" "+type);
                        }
                        input2 = choice2.nextInt();
                        switch (input2){
                            case 0:
                                myCar.Country();
                                break;

                            case 1:
                                myCar.needGasoline();
                                break;

                            case 2:
                                myCar.checkBatteryStatus();
                                break;

                            case 3:
                                myCar.horn();
                                break;

                            case 4:
                                myCar.drive(2000);
                                break;

                            case 5:
                                myCar.brake();
                                break;

                            case 6:
                                System.out.println("You quit the current car.");
                                break;

                            default: System.out.println("Your input is invalid!");
                                break;

                        }
                    } while (input2!=6);

                } else if (result == 1) {
                    Honda myCar;
                    myCar = new Honda(2012, "Civic");
                    int input2;
                    Scanner choice2 = new Scanner(System.in);
                    do {
                        ArrayList<String> Functions = new ArrayList<String>();
                        Functions.add("Introduction");
                        Functions.add("Check Gasoline");
                        Functions.add("Check Battery");
                        Functions.add("Horn");
                        Functions.add("Miles Driven");
                        Functions.add("Brake");
                        Functions.add("Quit");
                        System.out.println("You have randomly picked a car.\nHere are some basic functions:\n (Please type in the function number)");
                        for (String type:Functions) {
                            System.out.println("#"+Functions.indexOf(type)+" "+type);
                        }
                        input2 = choice2.nextInt();
                        switch (input2){
                            case 0:
                                myCar.Country();
                                break;

                            case 1:
                                myCar.needGasoline();
                                break;

                            case 2:
                                myCar.checkBatteryStatus();
                                break;

                            case 3:
                                myCar.horn();
                                break;

                            case 4:
                                myCar.drive(5000);
                                break;

                            case 5:
                                myCar.brake();
                                break;

                            case 6:
                                System.out.println("You quit the current car.");
                                break;

                            default: System.out.println("Your input is invalid!");
                                break;
                        }
                    } while (input2!=6);

                } else if  (result == 2) {
                    Chevy myCar;
                    myCar = new Chevy(2010, "Sonic");
                    int input2;
                    Scanner choice2 = new Scanner(System.in);
                    do {
                        ArrayList<String> Functions = new ArrayList<String>();
                        Functions.add("Introduction");
                        Functions.add("Check Gasoline");
                        Functions.add("Check Battery");
                        Functions.add("Horn");
                        Functions.add("Miles Driven");
                        Functions.add("Brake");
                        Functions.add("Quit");
                        System.out.println("You have randomly picked a car.\nHere are some basic functions:\n (Please type in the function number)");
                        for (String type:Functions) {
                            System.out.println("~"+Functions.indexOf(type)+" "+type);
                        }
                        input2 = choice2.nextInt();
                        switch (input2){
                            case 0:
                                myCar.Country();
                                break;

                            case 1:
                                myCar.needGasoline();
                                break;

                            case 2:
                                myCar.checkBatteryStatus();
                                break;

                            case 3:
                                myCar.horn();
                                break;

                            case 4:
                                myCar.drive(3500);
                                break;

                            case 5:
                                myCar.brake();
                                break;

                            case 6:
                                System.out.println("You quit the current car.");
                                break;

                            default: System.out.println("Your input is invalid!");
                                break;

                        }
                    } while (input2!=6);
                }

            } else if (input.equals("Quit")) {
                System.out.println("You quit the wheel.");
                System.exit(0);
            } else {
                System.out.println("Your input is invalid!\n");
            }
            System.out.println("Do you want to try again?");
        }while (!input.equals("Quit"));

    }
}

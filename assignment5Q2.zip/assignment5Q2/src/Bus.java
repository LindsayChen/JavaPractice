/**
 * Created by lindsaychen on 2017-06-06.
 */
public class Bus extends Vehicle implements Gasoline, Battery{

    @Override
    public void needGasoline() {
        System.out.println("I don't need gasoline now.");
    }

    @Override
    public void checkBatteryStatus() {
        System.out.println("I need a new battery");
    }

    @Override
    public void accelerate() {
        super.accelerate();
    }

    @Override
    public void decelerate() {
        super.decelerate();
    }

    @Override
    public void horn() {
        super.horn();
    }
}

/**
 * Created by lindsaychen on 2017-06-01.
 */
public class Car extends Vehicle implements FourWheels, Battery {

    public Car(int year) {
        super();
        modelYear = year;
    }

    private int modelYear;
    private double speed;
    private double acceleration;
    private int gear;


    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public void setAcceleration(double acceleration) {
        this.acceleration = acceleration;
    }

    public void drive(int distanceInMiles){
        System.out.println("Miles driven:" + distanceInMiles + "miles!");
    }

    public void changeGear(){
        if (speed >0 && speed <= 20 ){
            gear = 1;
        }

        else if (speed>20 && speed <=40) {
            gear = 2;
        }

        else if (speed >40 && speed <=65) {
            gear = 3;
        }

        else if (speed >65 && speed <=90) {
            gear = 4;
        }

        else if (speed >90) {
            gear = 5;
        }
        System.out.println("I am in gear " + gear +" of driving mode now.");
    }

    public void speedIncrease (double acceleration) {
        speed = speed + acceleration;
        System.out.println("My current speed is " + speed + " km/h.");
    }

    public void speedDecrease (int deceleration) {
        speed = speed - deceleration;
        System.out.println("My current speed is " + speed + " km/h.");
    }
    public void brake (){

        System.out.println("I am a car. I stopped.");
    }

    @Override
    public void checkBatteryStatus() {
        System.out.println("The battery is fully charged and ready to go!");
    }

    @Override
    public int numberOfWheels() {
        return 4;
    }

    @Override
    public void decelerate() {
        super.decelerate();
        System.out.println("So I can slow down.");
    }
}
//has engine, gearbox, seat
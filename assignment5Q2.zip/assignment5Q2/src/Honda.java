/**
 * Created by lindsaychen on 2017-06-06.
 */
public class Honda extends Car implements Gasoline, Country {
    private String modelName;
    private Engine engine;

    public Honda(int year, String model) {
        super(year);
        modelName = model;
    }

    @Override
    public void needGasoline() {
        System.out.println("I have 80% gasoline.");
    }

    @Override
    public String fromCountry() {
        return "Japan";
    }

    @Override
    public void checkBatteryStatus() {
        System.out.println("I have 50% battery.");
    }

    public void Country() {
        Honda myCivic = new Honda(2012, "Civic");
        String country = myCivic.fromCountry();
        System.out.println("I am a Civic made in 2012 and I am a brand from " + country);
    }

    public static void main(String[] args) {
        Engine HondaEngine = new Engine();
        HondaEngine.stop();
    }
}
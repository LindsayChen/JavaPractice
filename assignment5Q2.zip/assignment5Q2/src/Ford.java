
public class Ford extends Car implements Gasoline, Country {
    private String modelName;
    private Engine engine;

    public Ford(int year, String model) {
        super(year);
        modelName = model;
    }

    @Override
    public void needGasoline() {
        System.out.println("I have 50% gasoline.");
    }

    @Override
    public String fromCountry() {
        return "USA";
    }

    @Override
    public void checkBatteryStatus() {
        System.out.println("I have 80% battery.");
    }

    public void Country() {
        Ford myFocus = new Ford(2010, "Focus");
        String country = myFocus.fromCountry();
        System.out.println("I am a Focus made in 2010 and I am a brand from " + country);
    }

    @Override
    public void drive(int distanceInMiles) {
        super.drive(distanceInMiles);
    }

    public static void main(String[] args) {
        Engine FocusEngine = new Engine();
        FocusEngine.stop();
    }
}

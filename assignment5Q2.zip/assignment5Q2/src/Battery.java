/**
 * Created by lindsaychen on 2017-06-04.
 */
public interface Battery {
    public void checkBatteryStatus();
}

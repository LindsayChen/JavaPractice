/**
 * Created by lindsaychen on 2017-06-03.
 */
public interface Gasoline {
    public void needGasoline();
}

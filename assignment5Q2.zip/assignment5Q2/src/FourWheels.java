/**
 * Created by lindsaychen on 2017-06-03.
 */
public interface FourWheels {
    public int numberOfWheels();
}

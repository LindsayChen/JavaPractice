/**
 * Created by lindsaychen on 2017-06-02.
 */
public class Engine {

    public void start(){
        System.out.println("Engine started: Vroom!");
    }

    public void stop(){
        System.out.println("Engine stopped!");
    }

}
